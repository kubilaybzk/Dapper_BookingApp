﻿using System;
namespace Dapper_Web_Api.DTOs.WhoWeAreServices
{
	public class ResultWhoWeAreServicesDTOs
	{
        public int ServiceID { get; set; }
        public string ServiceName { get; set; }
        public bool ServiceStatus { get; set; }
    }
}

