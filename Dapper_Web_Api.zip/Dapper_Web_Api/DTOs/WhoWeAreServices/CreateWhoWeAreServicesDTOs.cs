﻿using System;
namespace Dapper_Web_Api.DTOs.WhoWeAreServices
{
	public class CreateWhoWeAreServicesDTOs
	{
        public string ServiceName { get; set; }
        public bool ServiceStatus { get; set; }
    }
}

