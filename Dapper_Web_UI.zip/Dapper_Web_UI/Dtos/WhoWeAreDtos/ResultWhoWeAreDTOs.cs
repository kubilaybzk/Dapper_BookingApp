﻿using System;
namespace Dapper_Web_UI.Dtos.WhoWeAreDtos
{
	public class ResultWhoWeAreDTOs
	{
        public int WhoWeAreDetailID { get; set; }
        public string Title { get; set; }
        public string Subtitle { get; set; }
        public string Description { get; set; }
        public string Description2 { get; set; }
    }
}

