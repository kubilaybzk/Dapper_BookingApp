﻿using System;
namespace Dapper_Web_Api.Concrete
{
	public class WhoWeAreServices
	{
		public WhoWeAreServices()
		{
		}
	}
}

