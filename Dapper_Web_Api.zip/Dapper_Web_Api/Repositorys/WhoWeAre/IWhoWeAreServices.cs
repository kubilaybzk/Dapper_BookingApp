﻿using System;
namespace Dapper_Web_Api.Repositorys.WhoWeAre
{
	public interface IWhoWeAreServices
	{
	}
}

