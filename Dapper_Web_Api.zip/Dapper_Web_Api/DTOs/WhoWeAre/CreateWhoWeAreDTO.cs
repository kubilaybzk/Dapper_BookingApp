﻿using System;
namespace Dapper_Web_Api.DTOs.WhoWeAre
{
	public class CreateWhoWeAreDTO
    {
        public string Title { get; set; }
        public string Subtitle { get; set; }
        public string Description { get; set; }
        public string Description2 { get; set; }
    }
}

